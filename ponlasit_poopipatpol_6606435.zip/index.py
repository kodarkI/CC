import os
import http.client
import ast
import logging
import queue
import threading
import base64
from io import BytesIO
import time
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, render_template
import math
import random
import pandas as pd
from datetime import date, timedelta
import numpy as np
import json
import statistics
import matplotlib.pyplot as plt
from get_data1 import get_data
from get_cal1 import get_cal
from threading import Thread
import gcsfs
from google.cloud import storage

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r'acquired-proxy-313611-1f281406dcad.json'
storage_client = storage.Client()

bucket_name = 'varbucket'


app = Flask(__name__)

# various Flask explanations available at:  https://flask.palletsprojects.com/en/1.1.x/quickstart/

def doRender(tname, values={}):
    if not os.path.isfile( os.path.join(os.getcwd(), 'templates/'+tname) ): #No such file
        return render_template('form.htm')
    return render_template(tname, **values) 

# Defines a POST supporting calculate route

var95s = None
var99s = None
runs = 5
tables2 = None

@app.route('/calculate', methods=['POST'])
def RandomHandler():
        
        if request.method == 'POST':
                D = request.form.get('D')
                H = request.form.get('H')
                T = request.form.get("signal")
                host = "9332uldq9f.execute-api.us-east-1.amazonaws.com"

                start = time.time()

                C, B, S_2, dates, data = get_data(1)

                
                minhistory = int(H)
                var95 = []
                var99 = []
                dated = []


                if T == "Buy":
                    for i in range(minhistory, len(data)): 
                        if B[i]==1: # if we’re interested in Buy signals
                            df_d = dates[i]
                            avg,std = get_cal(minhistory,C,i)
                            c = http.client.HTTPSConnection(host)
                            params = '{ "D": "'+D+'", "key1": "'+str(avg)+'", "key2": "'+str(std)+'"}'
                            json_input = json.dumps(params)
                            c.request("POST", "/default/F_1", params)
                            response = c.getresponse()
                            data = response.read().decode('utf-8')
                            print(data)
                            data = ast.literal_eval(data)
                            var95.append(data[0])
                            var99.append(data[1])
                            dated.append(df_d)

                elif T == "Sell":
                    for i in range(minhistory, len(data)): 
                        if S_2[i]==1: # if we’re interested in Buy signals
                            df_d = dates[i]
                            avg,std = get_cal(minhistory,C,i)
                            c = http.client.HTTPSConnection(host)
                            params = '{ "D": "'+D+'", "key1": "'+str(avg)+'", "key2": "'+str(std)+'"}'
                            json_input = json.dumps(params)
                            
                            c.request("POST", "/default/F_1", params)
                            response = c.getresponse()
                            data = response.read().decode('utf-8')
                            data = ast.literal_eval(data)
                            var95.append(data[0])
                            var99.append(data[1])
                            dated.append(df_d)

                df_marks = pd.DataFrame(dated,columns=['date'])
                df_marks['Var95'] = pd.DataFrame(var95)
                df_marks['Var99'] = pd.DataFrame(var99)
                df_marks.columns = ['Date', 'Var95','Var99']
                pd.set_option('display.max_colwidth', 40)
                tables=df_marks.to_html(col_space=150)

                var95 = df_marks['Var95']
                var99 = df_marks['Var99']
                mn95 = var95.mean()
                mn99 = var99.mean()

                idx,m95,m99,var95,var99 = Chart(var95,var99,mn95,mn99)
                Tend = time.time() - start
                Cs = Tend*0.0000021
                D_2 = []
                i = 0
                for i in range(i, len(var95)): D_2.append(D)
                H_2 = []
                i = 0
                for i in range(i, len(var95)): H_2.append(H)
                Td_2 = []
                i = 0
                for i in range(i, len(var95)): Td_2.append(Tend)
                T_2 = []
                i = 0
                for i in range(i, len(var95)): T_2.append(T)
                Cs_2 = []
                i = 0
                for i in range(i, len(var95)): Cs_2.append(Cs)
                df_marks['D'] = pd.DataFrame(D_2)
                df_marks['H'] = pd.DataFrame(H_2)
                df_marks['T'] = pd.DataFrame(T_2)
                df_marks['Time'] = pd.DataFrame(Td_2)
                df_marks['Cost'] = pd.DataFrame(Cs_2)
                #Upload csv to Google bucket
                bucket = storage_client.get_bucket('varbucket')
                blob = bucket.blob("Gotyou.csv")
                blob.upload_from_string(df_marks.to_csv(), 'text/csv')

                return doRender( 'form.htm',
                        {'result': tables,'D': D,'Tend':Tend,'T':T,'H':H,'Cs':Cs,'m99': m99,'m95': m95,'v99': var99,'v95': var95,'idx': idx} )

def Chart(var95,var99,mn95,mn99):
    m95 = []
    m99 = []
    idx = []
    i = 0
    for i in range(i, len(var95)): m95.append(mn95)
    i = 0
    for i in range(i, len(var99)): m99.append(mn99)
    i = 0
    for i in range(i, len(var95)): idx.append(i)
    var95 = var95.to_numpy().tolist()
    var99 = var99.to_numpy().tolist()

    return idx,m95,m99,var95,var99

@app.route('/page2.htm')
def get_analyses():

    #Download csv from Google bucket

    fs = gcsfs.GCSFileSystem(project='acquired-proxy-313611')
    with fs.open('varbucket/Gotyou.csv') as f:
        t22 = pd.read_csv(f)

    D = t22.iloc[1,4]
    H = t22.iloc[1,5]
    T = t22.iloc[1,6]
    Tend = t22.iloc[1,7]
    Cs = t22.iloc[1,8]
    var95_2 = t22.iloc[:,2]
    var99_2 = t22.iloc[:,3]

    mn95 = var95_2.mean()
    mn99 = var99_2.mean()


    idx,m95,m99,var95,var99 = Chart(var95_2,var99_2,mn95,mn99)

    t22.drop(t22.columns[[0,4,5,6,7,8]], axis = 1, inplace = True)
    tables2=t22.to_html(col_space=150)

    return doRender('page2.htm', {'m99': m99,'m95': m95,'v99': var99,'v95': var95,'idx': idx,'result': tables2,'D': D,'Tend':Tend,'T':T,'H':H,'Cs':Cs})

  


# catch all other page requests - doRender checks if a page is available (shows it) or not (index)
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def mainPage(path):
    return doRender(path)

@app.errorhandler(500)
# A small bit of error handling
def server_error(e):
    logging.exception('ERROR!')
    return """
    An  error occurred: <pre>{}</pre>
    """.format(e), 500

if __name__ == '__main__':
    # Entry point for running on the local machine
    # On GAE, endpoints (e.g. /) would be called.
    # Called as: gunicorn -b :$PORT index:app,
    # host is localhost; port is 5000; this file is index (.py)
    app.run(host='127.0.0.1', port=5000, debug=True)

