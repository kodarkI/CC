#!/usr/bin/env python3
import ast
import json
import math
import random
import boto3
import sys

def lambda_handler(event, context):
    
    # TODO implement
    D = int(event['D'])
    avg =  float(event['key1'])
    std = float(event['key2'])
    shots = D
    table = {}    
    var95_b2 = []
    var99_b2 = []
    simulated = [random.gauss(avg,std) for x in range(shots)]
    # sort and pick 95% and 99%  - not distinguishing long/short here
    simulated.sort(reverse=True)
    var95 = simulated[int(len(simulated)*0.95)]
    var99 = simulated[int(len(simulated)*0.99)]
    var95_b2.append(var95)
    var99_b2.append(var99)
    return(var95_b2,var99_b2) # so you can see what is being produced
        
    
