#!/usr/bin/python2.7

import math
import pandas as pd
import numpy as np



def get_cal(minhistory,C,i):
	avg = sum(C[i -minhistory:i]) / len(C[i-minhistory:i])
	total = 0.0
	for num in C[i-minhistory:i]:
		total += (num-avg)**2
		std = math.sqrt(total / (len(C[i-minhistory:i]) - 1)) 
			   	
	return avg,std
	
