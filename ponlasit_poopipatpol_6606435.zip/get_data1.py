#!/usr/bin/python2.7

import time
import math
import yfinance as yf
import pandas as pd
from datetime import date, timedelta
from pandas_datareader import data as pdr
import numpy as np

def get_data(d):
	yf.pdr_override()
	today = date.today()
	decadeAgo = today - timedelta(days=3652)
	data = pdr.get_data_yahoo('INTC', start=decadeAgo, end=today)
	D1 = data.index
	data['Buy']=0
	data['Sell']=0
	for i in range(len(data)):
		realbody=math.fabs(data.Open[i]-data.Close[i])
		bodyprojection=0.1*math.fabs(data.Close[i]-data.Open[i])          
		if data.High[i] >= data.Close[i] and data.High[i]-bodyprojection <= data.Close[i] and data.Close[i] > data.Open[i] and data.Open[i] > data.Low[i] and data.Open[i]-data.Low[i] > realbody:
			data.at[data.index[i], 'Buy'] = 1
		if data.High[i] > data.Close[i] and data.High[i]-data.Close[i] > realbody and data.Close[i] > data.Open[i] and data.Open[i] >= data.Low[i] and data.Open[i] <= data.Low[i]+bodyprojection:
			data.at[data.index[i], 'Buy'] = 1
		if data.High[i] >= data.Open[i] and data.High[i]-bodyprojection <= data.Open[i] and data.Open[i] > data.Close[i] and data.Close[i] > data.Low[i] and data.Close[i]-data.Low[i] > realbody:
			data.at[data.index[i], 'Sell'] = 1
		if data.High[i] > data.Open[i] and data.High[i]-data.Open[i] > realbody and data.Open[i] > data.Close[i] and data.Close[i] >= data.Low[i] and data.Close[i] <= data.Low[i]+bodyprojection:
			data.at[data.index[i], 'Sell'] = 1
	C = [entry[3] for entry in data.pct_change(1).values.tolist()]
	B = [entry[6] for entry in data.values.tolist()]
	S = [entry[7] for entry in data.values.tolist()]
	dates = [entry for entry in D1.tolist()]

	return C, B, S, dates, data